package TestCases;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import TestNG.DemoTestNG;

@Test
public class Practice1 extends DemoTestNG {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

}
