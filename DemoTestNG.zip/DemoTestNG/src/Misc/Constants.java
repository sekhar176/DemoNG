package Misc;

public class Constants {

	public static final String  excelpath = "./TestData/TestData.xlsx";

	}


